create PACKAGE BODY pgk_staff AS

    PROCEDURE delete_staff (
        p_staff_code STRING,
        p_person_update STRING
    )
        AS
    BEGIN
        UPDATE staff s
        SET
            s.status = 0,
            s.user_update = p_person_update,
            s.date_update = current_date
        WHERE
            s.staff_id = p_person_update;
-- UPDATE STATUS MEDIA

--        UPDATE media m
--            SET
--                m.status =-1,
--                m.user_update = p_person_update,
--                m.date_update = current_date
--        WHERE
--            m.staff_id IN (
--                SELECT
--                    staff_id
--                FROM
--                    media
--                WHERE
--                    staff_id = p_staff_id
--            );
          
--    UPDATE STATUS NOTIFICATION

--        UPDATE company_notification b
--            SET
--                b.status =-1,
--                b.user_update = p_person_update,
--                b.date_update = current_date
--        WHERE
--            b.staff_id IN (
--                SELECT
--                    STAFF_ID
--                FROM
--                    company_notification
--                WHERE
--                    company_notification.staff_id = staff.STAFF_ID 
--            );
--

    END delete_staff;

    PROCEDURE get_one_staff (
        o_res          OUT SYS_REFCURSOR,
        p_staff_code   IN STRING
    )
        AS
    BEGIN
        OPEN o_res FOR SELECT
            s.staff_code staffcode,
            s.staff_name staffname,
            (
                CASE s.gender
                    WHEN 0   THEN 'Nam'
                    WHEN 1   THEN 'Nữ'
                    ELSE ''
                END
            ) gender,
            s.date_of_birth dob,
            s.address address,
            s.temporary_address tempaddress,
            s.identification_card idcard,
            s.date_of_issue doi,
            s.place_of_issue poi,
            s.phone_number phonenum,
            s.email email,
            s.banking_account bankaccount,
            s.tax_code taxcode,
            s.staff_degree staffdegree,
            s.num_login_fail numloginfail,
            (
                CASE s.look_status
                    WHEN 0   THEN 'Khác'
                    WHEN 1   THEN 'Đang làm việc'
                    ELSE ''
                END
            ) lookstatus,
            s.start_probationary_perio startprodationary,
            s.start_working_day startworkday,
            s.end_working_day endworkday,
            s.position position
                       FROM
            staff s
    --join left MEDIA me on me.STAFF_ID=s.staff_id
                       WHERE
            (
                p_staff_code IS NULL
                OR s.staff_code = p_staff_code
            )
            AND s.status = 1;

    END get_one_staff;

    PROCEDURE get_all_staff (
        o_res OUT SYS_REFCURSOR
    )
        AS
    BEGIN
        OPEN o_res FOR SELECT
            s.staff_code staffcode,
            s.staff_name staffname,
            (
                CASE s.gender
                    WHEN 0   THEN 'Nam'
                    WHEN 1   THEN 'Nữ'
                    ELSE ''
                END
            ) gender,
            s.date_of_birth dob,
            s.address address,
            s.temporary_address tempaddress,
            s.identification_card idcard,
            s.date_of_issue doi,
            s.place_of_issue poi,
            s.phone_number phonenum,
            s.email email,
            s.banking_account bankaccount,
            s.tax_code taxcode,
            s.staff_degree staffdegree,
            s.num_login_fail numloginfail,
            (
                CASE s.look_status
                    WHEN 0   THEN 'Khác'
                    WHEN 1   THEN 'Đang làm việc'
                    ELSE ''
                END
            ) lookstatus,
            s.start_probationary_perio startprodationary,
            s.start_working_day startworkday,
            s.end_working_day endworkday,
            s.position position,
            s.USER_CREATED user_created,
            s.DATE_CREATED date_created,
            s.USER_UPDATE user_update,
            s.DATE_UPDATE date_update,
            s.STATUS status
                       FROM
            staff s;

    END get_all_staff;

    PROCEDURE getcompanyonsite (
        p_code   IN STRING,
        o_res    OUT SYS_REFCURSOR
    )
        AS
    BEGIN
        OPEN o_res FOR SELECT
            c.company_code,
            c.company_name,
            c.email,
            c.fax,
            c.latitude,
            c.longitude,
            c.phone_number,
            c.tax_code,
            c.title,
            c.website,
            c.address
                       FROM
            company c
                       WHERE
             c.COMPANY_CODE like 'OUT%' and company_id IN (
                SELECT
                    cp.company_id
                FROM
                    company_project cp
                    JOIN staff s ON s.staff_id = cp.staff_id and s.STAFF_CODE = p_code
            );

    END;
     
    

    
    
    
    
    

--    PROCEDURE get_a (
--        p_id                 STRING,
--        p_code               STRING,
--        p_name               STRING,
--        p_dob                DATE,
--        p_address            STRING,
--        p_sex                NUMBER,
--        p_startworkingdate   DATE,
--        --LOOK STATUS
--        p_position           STRING,
--        cur_result           OUT SYS_REFCURSOR
--    )
--        AS
--    BEGIN
--        OPEN cur_result FOR SELECT
--            s.staff_name,
--            s.gender,
--            s.date_of_birth,
--            s.phone_number,
--            s.email,
--            s.degree,
--            s.look_status,
--            s.address,
--            s.temporary_address,
--            s.identification_card,
--            s.date_of_issue,
--            s.place_of_issue,
--            s.banking_account,
--            s.tax_code,
--            s.position,
--            s.look_status,
--            s.start_probationary_perio,
--            s.end_probationary_perio,
--            s.start_working_day,
--            s.end_working_day
--                            FROM
--            staff s
--                            WHERE
--            (
--                p_id IS NULL
--                OR    s.staff_id = p_id
--            )
--            AND 
--            
--            
--            --HUY DAU VA IN HOA LIKE
--             (
--                p_code IS NULL
--                OR    s.staff_code = p_code
--            )
--            AND   (
--                p_name IS NULL
--                OR    s.staff_name = p_name
--            )
--            AND   (
--                p_dob IS NULL
--                OR    s.date_of_birth = p_dob
--            )
--            AND   (
--                p_address IS NULL
--                OR    s.address = p_address
--            )
--            AND   (
--                p_sex IS NULL
--                OR    s.gender = p_sex
--            )
--            AND   (
--                p_startworkingdate IS NULL
--                OR    s.start_working_day = p_startworkingdate
--            )
--            AND   (
--                p_position IS NULL
--                OR    s.position = p_position
--            );
--
--    END get_a;

END pgk_staff;
/

