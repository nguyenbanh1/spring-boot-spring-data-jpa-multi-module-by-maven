create PACKAGE pgk_staff AS
    
    --CHI Nguyen 8/8/2018
    PROCEDURE delete_staff (
        p_staff_code STRING,
            p_person_update STRING
    );
    
    
    --CHINGUYEN 17/8/2018
    PROCEDURE get_one_staff(
        o_res OUT SYS_REFCURSOR,
        p_staff_code IN STRING 
    );
    
    PROCEDURE get_all_staff(
        o_res OUT SYS_REFCURSOR
    );
    
    procedure getCompanyOnsite(p_code in String,o_res out sys_refcursor);
    
    
    

    -- Hữu Nhân 090818
--
--    PROCEDURE get_a (
--        p_id                 STRING,
--        p_code               STRING,
--        p_name               STRING,
--        p_dob                DATE,
--        p_address            STRING,
--        p_sex                NUMBER,
--        p_startworkingdate   DATE,
--        p_position           STRING,
--        cur_result           OUT SYS_REFCURSOR
--    );

END pgk_staff;
/

