create PACKAGE PGK_TIMESHEET_DETAIL AS 
--chi nguyen8/8/2018 delete
    PROCEDURE delete_timesheet_detail(
        p_timesheet_detail_id STRING,
        p_person_update string
    );
END PGK_TIMESHEET_DETAIL;
/

