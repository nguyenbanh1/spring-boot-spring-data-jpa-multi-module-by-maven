create PACKAGE BODY pgk_map_project_staff AS

    PROCEDURE delete_map_project_staff (
        p_id              IN STRING,
        p_person_update   IN STRING
    )
        AS
    BEGIN
        UPDATE map_project_staff m
            SET
                m.user_update = p_person_update,
                m.date_update = current_date,
                m.status =-1
        WHERE
            m.map_project_staff_id = p_id;

    END delete_map_project_staff;
    

END pgk_map_project_staff;
/

