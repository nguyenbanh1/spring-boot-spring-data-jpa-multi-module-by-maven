create PACKAGE BODY pgk_company_notification AS

    PROCEDURE delete_company_notification (
        p_id STRING,
        p_user_update STRING
    )
        AS
    BEGIN
        UPDATE company_notification
            SET
                user_update = p_user_update,
                status = 0
        WHERE
            apply_for_id = p_id;
        
        
        -- xoa bang apply_for_detail        

        UPDATE apply_for_detail
            SET
                status = 0
        WHERE
            apply_for_detail_id IN (
                SELECT
                    s.apply_for_detail_id
                FROM
                    apply_for_detail s
                WHERE
                    s.notification_id = p_id
            );  
        
        -- xoa bang staff_notification...

        UPDATE map_staff_notification
            SET
                status = 0
        WHERE
            map_staff_notification_id IN (
                SELECT
                    t.map_staff_notification_id
                FROM
                    map_staff_notification t
                WHERE
                    t.company_notification_id = p_id
            );

    END;
    
    procedure get_company_noti(rest out sys_refcursor, p_company_noti_type String,p_applyfor String)as
    begin
        open rest for
            select cn.COMPANY_NOTIFICATION_CODE as code,cn.COMPANY_NOTIFICATION_NAME as name,cn.COMPANY_NOTIFICATION_TYPE as type,cn.COMPANY_NOTIFICATION_CONTENT as content,cn.STATUS as status
            from COMPANY_NOTIFICATION cn 
            where cn.COMPANY_NOTIFICATION_TYPE like p_company_noti_type and cn.APPLY_FOR_ID = p_applyfor;
    end get_company_noti;
        
        

END pgk_company_notification;
/

