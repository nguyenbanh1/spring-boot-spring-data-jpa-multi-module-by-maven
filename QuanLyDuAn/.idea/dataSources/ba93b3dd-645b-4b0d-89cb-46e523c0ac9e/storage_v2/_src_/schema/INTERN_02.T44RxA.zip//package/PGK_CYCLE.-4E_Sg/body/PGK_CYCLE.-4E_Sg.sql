create PACKAGE BODY pgk_cycle AS

    PROCEDURE delete_cycle (
        p_cycle_id        IN STRING,
        p_person_update   IN STRING
    )
        AS
    BEGIN
        UPDATE cycle c
            SET
                c.date_update = current_date,
                c.user_update = p_person_update,
                c.status =-1
        WHERE
            c.cycle_code = p_cycle_id;

        UPDATE salary s
            SET
                s.status =-1,
                s.user_update = p_person_update,
                s.date_updated = current_date
        WHERE
            s.cycle_id = p_cycle_id;

        UPDATE timesheet t
            SET
                t.status =-1,
                t.user_update = p_person_update,
                t.date_update = current_date
        WHERE
            t.cycle_id = p_cycle_id;

    END delete_cycle;

END pgk_cycle;
/

