create PACKAGE BODY PGK_SALARY_DETAIL AS

  PROCEDURE delete_salary_detail (
        p_salary_detail_id STRING,
        p_person_update String
    ) AS
  BEGIN
    
    update SALARY_DETAIL sd
        set 
            sd.status=-1,
            sd.date_update = current_date,
            sd.USER_UPDATE = p_person_update       
        where sd.salary_detail_id=p_salary_detail_id;
  END delete_salary_detail;
  
  
  PROCEDURE get_one_salary(
        o_res OUT SYS_REFCURSOR,
        p_salary_detail_id STRING 
    )
    as
    BEGIN
    
    OPEN o_res FOR SELECT
            *
                       FROM
            SALARY_DETAIL
                       WHERE
            (
                p_salary_detail_id IS NULL
                OR salary_detail_id = p_salary_detail_id
            );
  END get_one_salary;

END PGK_SALARY_DETAIL;
/

