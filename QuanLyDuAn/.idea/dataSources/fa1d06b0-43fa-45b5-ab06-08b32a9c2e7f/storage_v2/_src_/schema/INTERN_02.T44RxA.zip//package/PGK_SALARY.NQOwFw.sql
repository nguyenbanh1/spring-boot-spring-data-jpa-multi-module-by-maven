create PACKAGE PGK_SALARY AS 
--chi nguyen 8/8/2018 v0.1
  PROCEDURE delete_salary(
        p_salary_id STRING ,
        person_update String
    );
    --chi nguyen 9/8/2018
    
    --v0.1
    PROCEDURE get_one_salary_one_staff(
        o_res OUT SYS_REFCURSOR,
        p_staff_id STRING 
    );
    --v0.1
    PROCEDURE get_list_salary(
        o_res OUT SYS_REFCURSOR
    );
    --v0.1
    PROCEDURE get_one_salary(
        o_res OUT SYS_REFCURSOR,
        p_salary_id STRING 
    );
    
END PGK_SALARY;
/

