create PACKAGE BODY PGK_TIMESHEET_DETAIL AS

  PROCEDURE delete_timesheet_detail(
        p_timesheet_detail_id STRING,
        p_person_update string
    ) AS
  BEGIN
    UPDATE timesheet_detail
        SET
            timesheet_detail.status =-1,
            user_update=p_person_update,
            date_update=current_date
        WHERE
            timesheet_detail.timesheet_detail_id = p_timesheet_detail_id;
  END delete_timesheet_detail;

END PGK_TIMESHEET_DETAIL;
/

