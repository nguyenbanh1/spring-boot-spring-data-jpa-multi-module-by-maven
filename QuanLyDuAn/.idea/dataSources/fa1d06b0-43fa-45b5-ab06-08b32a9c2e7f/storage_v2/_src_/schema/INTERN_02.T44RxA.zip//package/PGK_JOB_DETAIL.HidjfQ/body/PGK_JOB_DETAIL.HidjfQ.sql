create PACKAGE BODY PGK_JOB_DETAIL AS
    
    PROCEDURE DELETE_JOB_DETAIL(P_JOB_DETAIL_ID STRING,p_user_update String)as
    begin
        update JOB_DETAIL
            set STATUS = -1,USER_UPDATE = p_user_update,DATE_UPDATE = current_date
            where JOB_DETAIL_ID = p_job_detail_id;
    
    end DELETE_JOB_DETAIL;
    
END PGK_JOB_DETAIL;
/

