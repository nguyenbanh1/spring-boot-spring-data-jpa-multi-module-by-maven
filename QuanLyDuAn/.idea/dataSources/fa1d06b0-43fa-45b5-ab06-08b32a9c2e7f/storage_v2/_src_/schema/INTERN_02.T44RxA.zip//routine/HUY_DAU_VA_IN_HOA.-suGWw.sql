create FUNCTION HUY_DAU_VA_IN_HOA (
    p_str IN VARCHAR2
) RETURN VARCHAR2
IS

    v_result   VARCHAR2(180);
    v_char     VARCHAR2(10);
    v_str      VARCHAR2(180);
    v_len      NUMBER;
BEGIN
    v_str := trim(rtrim(p_str));
    v_len := length(v_str);
    IF
        v_str IS NULL
    THEN
        RETURN ' ';
    END IF;
    FOR i IN 1..v_len LOOP
        v_char := substr(v_str,i,1);
        IF
            v_char IN (
                'à',
                'á',
                'ạ',
                'ả',
                'ã',
                'â',
                'ầ',
                'ấ',
                'ậ',
                'ẩ',
                'ẫ',
                'ă',
                'ằ',
                'ắ',
                'ặ',
                'ẳ',
                'ẵ'
            )
        THEN
            v_char := 'a';
        END IF;

        IF
            v_char IN (
                'è',
                'é',
                'ẹ',
                'ẻ',
                'ẽ',
                'ê',
                'ề',
                'ế',
                'ệ',
                'ể',
                'ễ'
            )
        THEN
            v_char := 'e';
        END IF;

        IF
            v_char IN (
                'ì',
                'í',
                'ị',
                'ỉ',
                'ĩ'
            )
        THEN
            v_char := 'i';
        END IF;

        IF
            v_char IN (
                'ò',
                'ó',
                'ọ',
                'ỏ',
                'õ',
                'ô',
                'ồ',
                'ố',
                'ộ',
                'ổ',
                'ỗ',
                'ơ',
                'ờ',
                'ớ',
                'ợ',
                'ở',
                'ỡ'
            )
        THEN
            v_char := 'o';
        END IF;

        IF
            v_char IN (
                'ù',
                'ú',
                'ụ',
                'ủ',
                'ũ',
                'ư',
                'ừ',
                'ứ',
                'ự',
                'ử',
                'ữ'
            )
        THEN
            v_char := 'u';
        END IF;

        IF
            v_char IN (
                'ỳ',
                'ý',
                'ỵ',
                'ỷ',
                'ỹ'
            )
        THEN
            v_char := 'y';
        END IF;

        IF
            v_char IN (
                'đ'
            )
        THEN
            v_char := 'd';
        END IF;
        IF
            v_char IN (
                'À',
                'Á',
                'Ạ',
                'Ả',
                'Ã',
                'Â',
                'Ầ',
                'Ấ',
                'Ậ',
                'Ẩ',
                'Ẫ',
                'Ă',
                'Ằ',
                'Ắ',
                'Ặ',
                'Ẳ',
                'Ẵ'
            )
        THEN
            v_char := 'A';
        END IF;

        IF
            v_char IN (
                'È',
                'É',
                'Ẹ',
                'Ẻ',
                'Ẽ',
                'Ê',
                'Ề',
                'Ế',
                'Ệ',
                'Ể',
                'Ễ'
            )
        THEN
            v_char := 'E';
        END IF;

        IF
            v_char IN (
                'Ì',
                'Í',
                'Ị',
                'Ỉ',
                'Ĩ'
            )
        THEN
            v_char := 'I';
        END IF;

        IF
            v_char IN (
                'Ò',
                'Ó',
                'Ọ',
                'Ỏ',
                'Õ',
                'Ô',
                'Ồ',
                'Ố',
                'Ộ',
                'Ổ',
                'Ỗ',
                'Ơ',
                'Ờ',
                'Ớ',
                'Ợ',
                'Ở',
                'Ỡ'
            )
        THEN
            v_char := 'O';
        END IF;

        IF
            v_char IN (
                'Ù',
                'Ú',
                'Ụ',
                'Ủ',
                'Ũ',
                'Ư',
                'Ừ',
                'Ứ',
                'Ự',
                'Ử',
                'Ữ'
            )
        THEN
            v_char := 'U';
        END IF;

        IF
            v_char IN (
                'Ỳ',
                'Ý',
                'Ỵ',
                'Ỷ',
                'Ỹ'
            )
        THEN
            v_char := 'Y';
        END IF;

        IF
            v_char IN (
                'Đ'
            )
        THEN
            v_char := 'D';
        END IF;
        v_result := v_result
        || v_char;
    END LOOP;

    RETURN UPPER(v_result);
END;
/

