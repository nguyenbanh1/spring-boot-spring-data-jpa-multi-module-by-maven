create PACKAGE BODY PGK_SALARY AS

  PROCEDURE delete_salary(
        p_salary_id STRING,
        person_update STRING
    ) AS
  BEGIN
    UPDATE salary s
        SET
            s.status =-1,
            s.user_update=person_update,
            s.date_updated=current_date
        WHERE
            s.salary_id = p_salary_id;
    update SALARY_DETAIL sd
        set 
            sd.status=-1,
            sd.date_update = current_date,
            sd.USER_UPDATE = person_update       
        where sd.salary_id=p_salary_id;
  END delete_salary;
  
   PROCEDURE get_one_salary_one_staff(
        o_res OUT SYS_REFCURSOR,
        p_staff_id STRING 
    ) as
    BEGIN
     OPEN o_res FOR SELECT
            s.staff_code                            staffCode,
            s.staff_name                            staffName,
            sa.ACTUAL_NUMBER_WORK_DATE              actualWorkDay,
            sa.NUMBER_REST_DAY                      restDay,
            sa.NUMBER_WORK_DAY                      workDay,
            sad.START_DATE                          startDate,
            sad.END_DATE                            endDate,
            sad.SALARY_OT                           salaryOt,
            sad.SALARY_OTHER                        salaryOther,
            sad.REASON_FOR_SALARY_OTHER             reason,
            sad.SALARY_TOTAL                        salaryTotal
                       FROM
            SALARY sa
            Join SALARY_DETAIL  sad on sad.salary_id=sa.salary_id
            join staff           s   on s.staff_id=p_staff_id
                       WHERE
            (
                p_staff_id IS NULL
                OR sa.staff_id= p_staff_id
            )and sa.status=-1;
  END get_one_salary_one_staff;

    PROCEDURE get_list_salary(
        o_res OUT SYS_REFCURSOR
    ) as
    BEGIN
     OPEN o_res FOR SELECT
            s.staff_code                            staffCode,
            s.staff_name                            staffName,
            sad.SALARY_OTHER                        salaryOther,
            sad.SALARY_TOTAL                        salaryTotal
                       FROM
            SALARY sa
            left Join SALARY_DETAIL  sad on sad.salary_id=sa.salary_id
            left join staff           s   on s.staff_id=sa.staff_id;
                      
  END get_list_salary;
  --v0.1
  PROCEDURE get_one_salary(
        o_res OUT SYS_REFCURSOR,
        p_salary_id STRING 
    ) as
    BEGIN
     OPEN o_res FOR SELECT
            s.staff_code                            staffCode,
            s.staff_name                            staffName,
            sa.ACTUAL_NUMBER_WORK_DATE              actualWorkDay,
            sa.NUMBER_REST_DAY                      restDay,
            sa.NUMBER_WORK_DAY                      workDay,
            sad.START_DATE                          startDate,
            sad.END_DATE                            endDate,
            sad.SALARY_OT                           salaryOt,
            sad.SALARY_OTHER                        salaryOther,
            sad.REASON_FOR_SALARY_OTHER             reason,
            sad.SALARY_TOTAL                        salaryTotal
                       FROM
            SALARY sa
            left Join SALARY_DETAIL  sad on sad.salary_id=sa.salary_id
            left join staff           s   on s.staff_id=sa.staff_id
            WHERE
            (
                p_salary_id IS NULL
                OR sa.salary_id= p_salary_id
            )and sa.status=-1;
                      
  END get_one_salary;
  
END PGK_SALARY;
/

