create PACKAGE BODY pgk_apply_for AS

    PROCEDURE delete_apply_for (
        p_apply_for STRING,
        p_user_update STRING
    )
        AS
    BEGIN
        UPDATE apply_for
            SET
                status =-1,
                user_updated = p_user_update,
                date_updated = current_date
        WHERE
            apply_for_id = p_apply_for;


        -----------company_notification-------------

        UPDATE COMPANY_NOTIFICATION cn
            SET
                cn.status =-1,
                cn.user_update = p_user_update,
                cn.DATE_UPDATE  = current_date
        WHERE
            cn.COMPANY_NOTIFICATION_ID IN (
                SELECT
                    cn.company_notification_id
                FROM
                    company_notification
                WHERE
                    company_notification.apply_for_id = p_apply_for
            );


        ---------------- conf_contract------------------

        update CONF_CONTRACT cc
        set cc.STATUS = -1,cc.USER_UPDATE = p_user_update,cc.DATE_UPDATE = current_date
        where cc.CONF_CONTRACT_ID in (
                select conf_contract.CONF_CONTRACT_ID from conf_contract
                where CONF_CONTRACT.APPLY_FOR_ID = p_apply_for

        );





        -------------------apply_for_detail-------------------

        update APPLY_FOR_DETAIL afd
        set afd.STATUS = -1,afd.USER_UPDATED = p_user_update,afd.DATE_UPDATED = current_date
        where afd.APPLY_FOR_DETAIL_ID in 
                                        (
                                            select apply_for_detail.APPLY_FOR_DETAIL_ID from apply_for_detail
                                            where apply_for_detail.APPLY_FOR_ID = p_apply_for
                                        );

    END;

END pgk_apply_for;
/

