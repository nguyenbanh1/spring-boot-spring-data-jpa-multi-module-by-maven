create PACKAGE pgk_apply_for AS
    PROCEDURE delete_apply_for (
        p_apply_for STRING,
        p_user_update STRING
    );

END pgk_apply_for;
/

