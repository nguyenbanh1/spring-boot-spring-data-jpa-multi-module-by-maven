create PACKAGE BODY PGK_TIMESHEET AS

  PROCEDURE delete_timesheet(
        p_timesheet_id STRING,
        p_person_update string
    ) AS
  BEGIN
    UPDATE timesheet ts
        SET
            ts.status =-1,
            ts.user_update=p_person_update,
            ts.date_update=current_date
        WHERE
            ts.timesheet_id = p_timesheet_id;
        update timesheet_DETAIL tsd
        set 
            tsd.status=-1,
            tsd.date_update = current_date,
            tsd.USER_UPDATE = p_person_update       
        where tsd.timesheet_id  IN (SELECT timesheet_id FROM timesheet_DETAIL WHERE timesheet_id = p_timesheet_id);
  END delete_timesheet;

END PGK_TIMESHEET;
/

