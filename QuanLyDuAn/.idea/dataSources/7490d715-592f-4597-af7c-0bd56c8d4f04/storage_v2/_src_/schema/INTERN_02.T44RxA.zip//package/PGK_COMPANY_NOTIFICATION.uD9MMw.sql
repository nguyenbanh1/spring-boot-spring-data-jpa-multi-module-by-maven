create package pgk_company_notification as

    procedure delete_company_notification(p_id String,p_user_update String);



end pgk_company_notification;
/

