create PACKAGE pgk_configuration_master AS
    PROCEDURE get_all (
        o_res                  OUT SYS_REFCURSOR,
        p_configuration_id     STRING,
        p_configuration_code   STRING,
        p_object_type          STRING,
        p_object_id            STRING
    );

END pgk_configuration_master;
/

