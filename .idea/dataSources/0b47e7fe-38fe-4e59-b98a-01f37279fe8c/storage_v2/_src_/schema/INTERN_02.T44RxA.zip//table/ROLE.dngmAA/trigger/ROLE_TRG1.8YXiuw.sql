create trigger ROLE_TRG1
  before insert
  on ROLE
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

