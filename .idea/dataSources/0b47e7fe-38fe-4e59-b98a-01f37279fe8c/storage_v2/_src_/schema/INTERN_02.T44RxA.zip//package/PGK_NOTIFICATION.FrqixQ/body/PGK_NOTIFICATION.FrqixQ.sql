create PACKAGE BODY pgk_notification AS

    PROCEDURE get_one (
        o_res                         OUT SYS_REFCURSOR,
        p_company_notification_id     NUMBER,
        p_company_notification_code   STRING,
        p_apply_for_id                STRING,
        p_date_created                DATE,
        p_user_created                NUMBER
    )
        AS
    BEGIN
        OPEN o_res FOR SELECT
            *
                       FROM
            company_notification
                       WHERE
            (
                (
                    p_company_notification_id IS NULL
                    OR    company_notification.company_notification_id = p_company_notification_id
                )
                AND   (
                    p_company_notification_code IS NULL
                    OR    company_notification.company_notification_code = p_company_notification_code
                )
                AND   (
                    p_apply_for_id IS NULL
                    OR    company_notification.apply_for_id = p_apply_for_id
                )
                AND   (
                    p_date_created IS NULL
                    OR    company_notification.date_created = p_date_created
                )
                AND   (
                    p_user_created IS NULL
                    OR    company_notification.user_created = p_user_created
                )
            );

    END get_one;

END pgk_notification;
/

