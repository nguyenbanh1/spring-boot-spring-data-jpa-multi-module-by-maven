create package pgk_company as
    
    
    procedure delete_company(p_id String, p_user_update String);


end pgk_company;
/

