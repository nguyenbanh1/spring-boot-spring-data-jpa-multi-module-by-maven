create PACKAGE pgk_table_cv AS
    PROCEDURE get_all (
        o_res                    OUT SYS_REFCURSOR,
        p_cv_name                STRING,
        p_recruitment_position   STRING,
        p_date_recruitment       DATE
    );
--chi nguyen8/8/2018 delete
    PROCEDURE delete_table_cv (
        p_cv_id STRING,
        p_person_update string
    );

END pgk_table_cv;
/

