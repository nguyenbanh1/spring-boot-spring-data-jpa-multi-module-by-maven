create PACKAGE BODY pgk_staff AS

    PROCEDURE delete_staff (
        p_staff_id STRING,
        p_person_update STRING
    )
        AS
    BEGIN
        UPDATE staff s
            SET
                s.look_status =-1,
                s.user_update = p_person_update,
                s.date_update = current_date
        WHERE
            staff_id = p_staff_id;
        -- cac bảng con:
        --delete job_detail

        UPDATE job_detail jd
            SET
                jd.status =-1,
                jd.date_update = current_date,
                jd.user_update = p_person_update
        WHERE
            jd.staff_id IN (
                SELECT
                    staff_id
                FROM
                    staff
                WHERE
                    staff_id = p_staff_id
            );

        UPDATE job_detail jd
            SET
                jd.status =-1,
                jd.date_update = current_date,
                jd.user_update = p_person_update
        WHERE
            jd.staff_id IN (
                SELECT
                    staff_id
                FROM
                    job_detail
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete COMPANY_PROJECT

        UPDATE company_project cp
            SET
                cp.status =-1,
                cp.date_update = current_date,
                cp.user_update = p_person_update
        WHERE
            cp.staff_id IN (
                SELECT
                    staff_id
                FROM
                    company_project
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete table_cv

        UPDATE table_cv tc
            SET
                tc.status =-1,
                tc.date_update = current_date,
                tc.user_update = p_person_update
        WHERE
            tc.staff_id IN (
                SELECT
                    staff_id
                FROM
                    table_cv
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete map_project_staff

        UPDATE map_project_staff mps
            SET
                mps.status =-1,
                mps.date_update = current_date,
                mps.user_update = p_person_update
        WHERE
            mps.staff_id IN (
                SELECT
                    staff_id
                FROM
                    map_project_staff
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete map_user 

        UPDATE map_user ms
            SET
                ms.date_update = current_date,
                ms.user_update = p_person_update
        WHERE
            ms.staff_id IN (
                SELECT
                    staff_id
                FROM
                    map_user
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete timesheet

        UPDATE timesheet ts
            SET
                ts.status =-1,
                ts.date_update = current_date,
                ts.user_update = p_person_update
        WHERE
            ts.staff_id IN (
                SELECT
                    staff_id
                FROM
                    timesheet
                WHERE
                    staff_id = p_staff_id
            );
        
        --delete salary

        UPDATE salary sa
            SET
                sa.status =-1,
                sa.date_updated = current_date,
                sa.user_update = p_person_update
        WHERE
            sa.staff_id IN (
                SELECT
                    staff_id
                FROM
                    salary
                WHERE
                    staff_id = p_staff_id
            );

    END delete_staff;

    PROCEDURE get_a (
        p_id                 STRING,
        p_code               STRING,
        p_name               STRING,
        p_dob                DATE,
        p_address            STRING,
        p_sex                NUMBER,
        p_startworkingdate   DATE,
        --LOOK STATUS
        p_position           STRING,
        cur_result           OUT SYS_REFCURSOR
    )
        AS
    BEGIN
        OPEN cur_result FOR SELECT
            s.staff_name,
            s.gender,
            s.date_of_birth,
            s.phone_number,
            s.email,
            s.degree,
            s.look_status,
            s.address,
            s.temporary_address,
            s.identification_card,
            s.date_of_issue,
            s.place_of_issue,
            s.banking_account,
            s.tax_code,
            s.position,
            s.look_status,
            s.start_probationary_perio,
            s.end_probationary_perio,
            s.start_working_day,
            s.end_working_day
                            FROM
            staff s
                            WHERE
            (
                p_id IS NULL
                OR    s.staff_id = p_id
            )
            AND 
            
            
            --HUY DAU VA IN HOA LIKE
            (
                p_code IS NULL
                OR    s.staff_code = p_code
            )
            AND   (
                p_name IS NULL
                OR    s.staff_name = p_name
            )
            AND   (
                p_dob IS NULL
                OR    s.date_of_birth = p_dob
            )
            AND   (
                p_address IS NULL
                OR    s.address = p_address
            )
            AND   (
                p_sex IS NULL
                OR    s.gender = p_sex
            )
            AND   (
                p_startworkingdate IS NULL
                OR    s.start_working_day = p_startworkingdate
            )
            AND   (
                p_position IS NULL
                OR    s.position = p_position
            );

    END get_a;

END pgk_staff;
/

