create trigger SALARY_DETAIL_TRG
  before insert
  on SALARY_DETAIL
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

