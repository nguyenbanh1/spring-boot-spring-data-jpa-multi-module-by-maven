create PACKAGE pgk_media AS
    PROCEDURE delete_media (
        p_media_id STRING
    );

    PROCEDURE delete_media1 (
        p_user_update STRING,
        p_media_id STRING
    );

END pgk_media;
/

