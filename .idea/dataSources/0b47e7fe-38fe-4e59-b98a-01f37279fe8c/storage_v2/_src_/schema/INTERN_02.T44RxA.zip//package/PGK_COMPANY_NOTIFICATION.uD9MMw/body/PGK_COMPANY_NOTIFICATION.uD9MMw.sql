create package body pgk_company_notification as

    procedure delete_company_notification(p_id String,p_user_update String)as
    begin

        update company_notification
        set STATUS = -1,USER_UPDATE = p_user_update,DATE_UPDATE = current_date
        where COMPANY_NOTIFICATION_ID = p_id;

    end;



end pgk_company_notification;
/

