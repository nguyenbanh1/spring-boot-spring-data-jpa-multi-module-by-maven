create PACKAGE PGK_NOTIFICATION AS
    PROCEDURE get_one (
        o_res              OUT SYS_REFCURSOR,
        p_company_notification_id   NUMBER,
        p_company_notification_code STRING,
        p_apply_for_id STRING,
        p_date_created DATE,
        p_user_created NUMBER
    );

END PGK_NOTIFICATION;
/

