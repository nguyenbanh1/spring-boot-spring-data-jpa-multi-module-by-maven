create trigger JOB_DETAIL_TRG
  before insert
  on JOB_DETAIL
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

