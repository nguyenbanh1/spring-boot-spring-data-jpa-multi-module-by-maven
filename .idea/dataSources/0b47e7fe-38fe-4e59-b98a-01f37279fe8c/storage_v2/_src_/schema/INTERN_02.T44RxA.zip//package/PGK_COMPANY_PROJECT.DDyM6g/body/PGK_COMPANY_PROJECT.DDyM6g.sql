create PACKAGE BODY pgk_company_project AS

    PROCEDURE delete_company_project (
        p_company_id STRING,
        p_user_update STRING
    )
        AS
    BEGIN
        UPDATE company_project p
            SET
                p.status =-1,
                p.user_update = p_user_update,
                p.date_update = current_date
        WHERE
            p.company_project_id IN (
                SELECT
                    company_project_id
                FROM
                    company_project
                WHERE
                    company_id = p_company_id
            );

        UPDATE company cp
            SET
                cp.status =-1,
                cp.user_update = p_user_update,
                cp.date_update = current_date
        WHERE
            cp.company_id = p_company_id;

    END delete_company_project;

     PROCEDURE get_all_ds_project (
        o_res                           OUT SYS_REFCURSOR,
        p_company_project_id string,
        p_staff_id string,
        p_schedule_start_time date,
        p_schedule_end_time date
        
    )
        AS
    BEGIN
        OPEN o_res FOR SELECT
            cp.company_project_id,
            cp.schedule_start_time,
            cp.schedule_end_time,
            s.staff_name,
            cp.staff_id,
            cp.ACTUAL_END,
            cp.ACTUAL_START,
            cp.COMPANY_PROJECT_NAME,
            cp.COMPANY_PROJECT_DESCRIPTION,
            cp.CUSTOMER,
            cp.MAX_STAFF
            
                       FROM
            company_project cp
            JOIN map_user m ON m.staff_id = cp.staff_id
            JOIN staff s ON cp.staff_id = s.staff_id
                       WHERE
            (p_company_project_id is null or cp.COMPANY_PROJECT_ID = p_company_project_id
            )and
            (p_schedule_end_time is null or (cp.schedule_end_time <  p_schedule_end_time )
            or ( p_schedule_end_time < cp.schedule_end_time))and
            (p_schedule_start_time is null or (cp.schedule_start_time >  p_schedule_start_time)or
            ( cp.schedule_end_time < p_schedule_start_time)) and
            (p_staff_id is null or s.staff_name = p_staff_id)
            
            
            
            ;

    END get_all_ds_project;
    
    
    
     PROCEDURE get_one(
    o_res OUT SYS_REFCURSOR,
    o_res1 OUT SYS_REFCURSOR,
    p_company_project_id STRING    
    )
    AS BEGIN 
    OPEN o_res1 FOR SELECT  mps.COMPANY_PROJECT_ID , cp.COMPANY_PROJECT_NAME, cp.COMPANY_PROJECT_DESCRIPTION, cp.COST, cp.EXPECTED_COST,
     cp.ACTUAL_END,
            cp.ACTUAL_START,
            cp.COMPANY_PROJECT_NAME,
            cp.COMPANY_PROJECT_DESCRIPTION,
            cp.CUSTOMER,
            cp.MAX_STAFF
            from COMPANY_PROJECT cp join MAP_PROJECT_STAFF mps on cp.company_project_id = mps.company_project_id;
    OPEN o_res FOR SELECT s.staff_name, s.STAFF_ID,mps.BONUS, mps.PROGESS, mps.START_DATE, mps.END_DATE, mps.STAFF_EVALUATION FROM map_project_staff mps join staff s on s.staff_id = mps.staff_id
    where (mps.COMPANY_PROJECT_ID = p_company_project_id);
    END get_one;
    
    
    

END pgk_company_project;
/

