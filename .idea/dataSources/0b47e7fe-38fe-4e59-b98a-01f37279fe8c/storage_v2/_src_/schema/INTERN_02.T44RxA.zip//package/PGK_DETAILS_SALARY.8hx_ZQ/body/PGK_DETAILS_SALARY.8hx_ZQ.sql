create PACKAGE BODY pgk_details_salary AS

    PROCEDURE delete_details_salary (
        p_details_salary_id STRING
    )
        AS
    BEGIN
        UPDATE salary_detail
        SET
            status =-1
        WHERE
            salary_detail_id = p_details_salary_id;

    END delete_details_salary;

    FUNCTION get_all (
        p_details_salary_id STRING
    ) RETURN SYS_REFCURSOR AS
        o_res   SYS_REFCURSOR;
    BEGIN
        OPEN o_res FOR SELECT
            *
                       FROM
            salary_detail
                       WHERE
            (
                p_details_salary_id IS NULL
                OR salary_detail_id = p_details_salary_id
            );

    END get_all;
 

END pgk_details_salary;
/

