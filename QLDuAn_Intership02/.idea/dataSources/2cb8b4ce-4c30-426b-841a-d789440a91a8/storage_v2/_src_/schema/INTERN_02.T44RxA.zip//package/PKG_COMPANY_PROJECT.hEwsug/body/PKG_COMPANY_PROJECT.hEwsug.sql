create package body pkg_company_project as

    procedure delete_company_project(p_id String, p_user_update String)as
    
    begin
        update COMPANY_PROJECT 
        set STATUS = -1,USER_UPDATE = p_user_update,DATE_UPDATE = current_date
        where COMPANY_PROJECT_ID = p_id;


        -----------------map_project_staff----------------

        -------------job_detail-----------------



    end delete_company_project;


end pkg_company_project;
/

