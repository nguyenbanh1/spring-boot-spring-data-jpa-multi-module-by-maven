create package pkg_company_project as

    procedure delete_company_project(p_id String, p_user_update String);
end pkg_company_project;
/

