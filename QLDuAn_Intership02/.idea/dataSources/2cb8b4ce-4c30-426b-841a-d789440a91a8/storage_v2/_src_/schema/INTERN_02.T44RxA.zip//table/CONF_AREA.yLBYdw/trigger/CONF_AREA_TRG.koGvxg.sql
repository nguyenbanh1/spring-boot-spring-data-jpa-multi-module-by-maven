create trigger CONF_AREA_TRG
  before insert
  on CONF_AREA
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

