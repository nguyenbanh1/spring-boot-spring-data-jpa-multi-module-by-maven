create PACKAGE PGK_PROJECT1 AS
    
    procedure delete_company_project(p_company_id String,p_user_update String);
    
    
    --chi nguyen get 9/8/2018
    PROCEDURE get_one_project(
        o_res OUT SYS_REFCURSOR,
        p_salary_detail_id STRING 
    );
    

END PGK_PROJECT1;
/

