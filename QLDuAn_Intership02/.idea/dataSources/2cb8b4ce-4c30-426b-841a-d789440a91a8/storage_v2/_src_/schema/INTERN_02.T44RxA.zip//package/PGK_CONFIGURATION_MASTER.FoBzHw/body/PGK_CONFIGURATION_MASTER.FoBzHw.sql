create PACKAGE BODY pgk_configuration_master AS

    PROCEDURE get_all (
        o_res                  OUT SYS_REFCURSOR,
        p_configuration_id     STRING,
        p_configuration_code   STRING,
        p_object_type          STRING,
        p_object_id            STRING
    ) AS
    BEGIN
        OPEN o_res FOR SELECT
                           *
                       FROM
                           configuration_master
                       WHERE
                           ( ( p_configuration_code IS NULL
                               OR huy_dau_va_in_hoa(configuration_master.configuration_code) LIKE '%' || huy_dau_va_in_hoa(p_configuration_code
                               || '%') )
                             AND ( configuration_id IS NULL
                                   OR configuration_master.configuration_id = p_configuration_id )
                             AND ( p_object_type IS NULL
                                   OR configuration_master.object_type = p_object_type )
                             AND ( p_object_id IS NULL
                                   OR configuration_master.object_id = p_object_id ) );

    END get_all;

END pgk_configuration_master;w
/

