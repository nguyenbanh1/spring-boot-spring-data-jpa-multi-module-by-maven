create trigger COMPANY_TRG
  before insert
  on COMPANY
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

