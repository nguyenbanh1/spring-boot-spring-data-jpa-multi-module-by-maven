create trigger DAY_OFF_TRG
  before insert
  on DAY_OFF
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

