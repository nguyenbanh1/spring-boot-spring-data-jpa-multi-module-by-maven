create package body pkg_project  as

    procedure delete_project(id in String) as
    begin
        update PROJECT set PROJECT.STATUS = 0 where  PROJECT_ID = id;
        pkg_employee_project.delete_employee_project(id,'project');

    end;

end pkg_project;
/

