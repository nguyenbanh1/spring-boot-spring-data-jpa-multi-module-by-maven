create package body pkg_address as
    
    procedure addAddress(p_name in String)as
    begin
        insert into ADDRESS(ADDRESS_ID,ADDRESS_NAME) values (ADDRESS_SEQ.nextval,p_name);
    end addAddress;
    
    procedure getAll(status in String,o_res out sys_refcursor) -- nếu status = '1' thi lay status 1, con 0 la lay het
    as
    begin
        if status = '1' then
            open o_res for select * from ADDRESS where STATUS = '1';
            
        else 
            open o_res for select * from ADDRESS;
        end if;
 
    end getAll;
    
    
    procedure getDescriptionByName(p_name in String, p_description out String)as
    begin
        select DESCRIPTION into p_description from ADDRESS where ADDRESS_NAME = p_name;
    end getDescriptionByName;

  procedure isName(p_name in String,bl out INTEGER) as
    o_res sys_refcursor;
    begin
      bl := 1;
      open o_res for select * from ADDRESS;

      if o_res%notfound then
        bl := 2;
      end if;
      close o_res;
    end isName;

end pkg_address;
/

