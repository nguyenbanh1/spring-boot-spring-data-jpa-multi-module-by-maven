create package body pkg_employee as

  procedure delete_employee(id in string)as
    begin
      update EMPLOYEE set EMPLOYEE.STATUS = 0 where EMPLOYEE_ID = id;
      PKG_EMPLOYEE_PROJECT.DELETE_EMPLOYEE_PROJECT(id,'employee');
    end;

  procedure addEmployee(p_name in String, p_mail in String,p_address in INTEGER,p_status in String)as
    begin
        insert into EMPLOYEE(EMPLOYEE_NAME, EMPLOYEE_MAIL, ADDRESS_ID, STATUS)
          VALUES (p_name,p_mail,p_address,p_status);
    end;


end pkg_employee;
/

