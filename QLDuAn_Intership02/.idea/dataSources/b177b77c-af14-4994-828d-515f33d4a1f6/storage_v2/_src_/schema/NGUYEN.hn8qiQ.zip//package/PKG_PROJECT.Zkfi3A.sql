create package pkg_project as

    procedure delete_project(id in String);

end pkg_project;
/

