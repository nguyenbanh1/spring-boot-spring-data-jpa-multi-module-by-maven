create PACKAGE PGK_SALARY_DETAIL AS 
--Chi Nguyen 8/8/2018 xong delete
   PROCEDURE delete_salary_detail (
        p_salary_detail_id STRING,
        p_person_update String
    );
    
    PROCEDURE get_one_salary(
        o_res OUT SYS_REFCURSOR,
        p_salary_detail_id STRING 
    );
    
    
END PGK_SALARY_DETAIL;
/

