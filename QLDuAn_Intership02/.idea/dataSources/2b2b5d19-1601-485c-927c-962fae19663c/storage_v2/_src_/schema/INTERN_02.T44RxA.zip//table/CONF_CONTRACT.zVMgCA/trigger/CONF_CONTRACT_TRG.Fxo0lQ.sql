create trigger CONF_CONTRACT_TRG
  before insert
  on CONF_CONTRACT
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

