create PACKAGE pgk_conf_area AS
    PROCEDURE GET_ALL_AREA (
        O_RES               OUT SYS_REFCURSOR,
        P_AREA_CODE         STRING,
        P_AREA_NAME         STRING,
        P_PROVINCE_CODE     STRING,
        P_PROVINCE_NAME     STRING,
        P_DISTRICT_CODE     STRING,
        P_DISTRICT_NAME     STRING,
        P_COMMUNCE_CODE     STRING,
        P_COMMUNCE_NAME     STRING,
        P_PRECINCT_CODE     STRING,
        P_PRECINCT_NAME     STRING,
        P_TYPE              INT
    );

END pgk_conf_area;
/

