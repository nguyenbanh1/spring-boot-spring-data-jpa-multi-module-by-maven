create package pkg_employee_project as

    procedure delete_employee_project( p_id in integer,p_name_field in String);


end pkg_employee_project;
/

