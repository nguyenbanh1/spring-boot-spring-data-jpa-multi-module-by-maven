create package body pkg_test as

    procedure test(inParam1 in String,outParam2 out String)as
    begin
        outParam2 := 'Inparam 2 : ' + inParam1; 
    end test;

end pkg_test;
/

