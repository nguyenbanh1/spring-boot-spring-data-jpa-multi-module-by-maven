create package pkg_employee as

    procedure delete_employee(id in string);


    procedure addEmployee(p_name in String, p_mail in String,p_address in INTEGER,p_status in String);

    

end pkg_employee;
/

