create package body pkg_employee_project as

    procedure delete_employee_project( p_id in integer,p_name_field in String)as
        o_res sys_refcursor;
        this_record EMPLOYEE_PROJECT%rowtype;
    begin
    
        if p_name_field = 'employee' then
            --DBMS_OUTPUT.PUT_LINE('employee');
            open o_res for
                select * from EMPLOYEE_PROJECT where EMPLOYEE_ID = p_id;
        
        elsif p_name_field = 'project' then
            --DBMS_OUTPUT.PUT_LINE('project');
            open o_res for
                select * from EMPLOYEE_PROJECT where PROJECT_ID = p_id;
        else
            --DBMS_OUTPUT.PUT_LINE('other');

            o_res := NULL;
        end if;
        
        loop
            fetch o_res into this_record;
            update EMPLOYEE_PROJECT set STATUS = 0 where EMPLOYEE_PROJECT_ID = this_record.EMPLOYEE_PROJECT_ID;
            exit when o_res%notfound;
            --DBMS_OUTPUT.PUT_LINE(this_record.status);
        end loop;
  
    end;
end pkg_employee_project;
/

