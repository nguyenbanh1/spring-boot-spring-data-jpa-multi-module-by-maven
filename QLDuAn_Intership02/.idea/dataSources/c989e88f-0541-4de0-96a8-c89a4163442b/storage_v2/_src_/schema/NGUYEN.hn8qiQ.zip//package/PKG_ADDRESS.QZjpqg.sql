create package pkg_address as
    
    procedure addAddress(p_name in String);
    procedure getAll(status in String,o_res out sys_refcursor); -- nếu status = '1' thi lay status 1, con 0 la lay het
    procedure getDescriptionByName(p_name in String, p_description out String);
    procedure isName(p_name in String,bl out INTEGER);
end pkg_address;
/

