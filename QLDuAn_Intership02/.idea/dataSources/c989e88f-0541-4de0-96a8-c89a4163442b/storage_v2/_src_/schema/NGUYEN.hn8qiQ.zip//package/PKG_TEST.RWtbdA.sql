create package pkg_test as

    procedure test(inParam1 in String,outParam2 out String);

end pkg_test;
/

